# 每条任务的搜索行为对比

使用本次预算实验的80条有效轨迹，按源码行数排序。Redis plain采用基础设施补跑后的完整轨迹；原超时尝试不混入主表搜索量，费用仍保留在实验总账。

`×`表示该档官方任务测试未通过；其余为通过。数字为显式搜索请求中的子命令数，包括文本搜索/过滤和文件定位，不是成功检索次数。

| 仓库 | 源码行数 | plain | 1024 | 2048 | 4096 | 1024相对plain |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| [axios/axios](search-cases/axios__axios-4731.md) | 12,686 | 4 | 4 | 6 | 7 | +0 |
| [psf/requests](search-cases/psf__requests-1142.md) | 13,679 | 8 | 6 | 15 | 4 | -2 |
| [gin-gonic/gin](search-cases/gin-gonic__gin-1805.md) | 13,935 | 15 | 9 | 8 | 12 | -6 |
| [pallets/flask](search-cases/pallets__flask-5014.md) | 17,478 | 5 | 3 | 2 | 4 | -2 |
| [sharkdp/bat](search-cases/sharkdp__bat-1892.md) | 21,496 | 36 | 24 | 29 | 37 | -12 |
| [jekyll/jekyll](search-cases/jekyll__jekyll-8047.md) | 22,127 | 11 | 8 | 5 | 5 | -3 |
| [google/gson](search-cases/google__gson-1014.md) | 36,759 | 6 | 6 | 3 | 3 | +0 |
| [preactjs/preact](search-cases/preactjs__preact-2757.md) | 37,908 | 3 | 7 | 3 | 7 | +4 |
| [burntsushi/ripgrep](search-cases/burntsushi__ripgrep-2209.md) | 41,249 | 18 | 12 | 13 | 13 | -6 |
| [jqlang/jq](search-cases/jqlang__jq-2235.md) | 45,247 | 9 | 12 | 21 | 17 | +3 |
| [caddyserver/caddy](search-cases/caddyserver__caddy-4774.md) | 54,265 | 15 × | 8 × | 16 × | 10 × | -7 |
| [fmtlib/fmt](search-cases/fmtlib__fmt-1683.md) | 67,663 | 18 × | 12 × | 25 | 10 | -6 |
| [tokio-rs/tokio](search-cases/tokio-rs__tokio-4384.md) | 108,282 | 12 | 14 | 18 | 31 | +2 |
| [redis/redis](search-cases/redis__redis-10068.md) | 245,197 | 11 | 9 | 14 | 11 | -2 |
| [rubocop/rubocop](search-cases/rubocop__rubocop-13362.md) | 283,279 | 7 | 4 | 12 | 9 | -3 |
| [briannesbitt/carbon](search-cases/briannesbitt__carbon-2665.md) | 313,470 | 17 | 21 | 12 | 18 | +4 |
| [django/django](search-cases/django__django-10097.md) | 352,429 | 12 | 8 | 12 | 11 | -4 |
| [laravel/framework](search-cases/laravel__framework-46234.md) | 354,539 | 10 × | 14 × | 7 × | 4 × | +4 |
| [sympy/sympy](search-cases/sympy__sympy-11618.md) | 446,166 | 12 | 6 | 3 × | 5 | -6 |
| [apache/lucene](search-cases/apache__lucene-11760.md) | 1,188,071 | 5 × | 10 × | 18 × | 4 × | +5 |
| **合计** | | 234 | 197 | 242 | 222 | −37 |

1024相比plain：搜索减少12条、持平2条、增加6条；总量减少15.8%。2048为9条减少、2条持平、9条增加；4096为12条减少、1条持平、7条增加。

fmt在2048档搜索25次并通过，plain搜索18次但失败；SymPy在2048档仅搜索3次却失败。搜索次数需要与最终是否修复成功一起看。

## 含搜索的Bash请求数

一条Bash请求可能含多个grep/find；下表每条含搜索的Bash动作只计一次。

| 仓库 | plain | 1024 | 2048 | 4096 |
| --- | ---: | ---: | ---: | ---: |
| axios/axios | 4 | 4 | 5 | 7 |
| psf/requests | 7 | 6 | 11 | 4 |
| gin-gonic/gin | 13 | 6 | 8 | 9 |
| pallets/flask | 5 | 3 | 2 | 4 |
| sharkdp/bat | 28 | 21 | 24 | 29 |
| jekyll/jekyll | 8 | 7 | 5 | 4 |
| google/gson | 5 | 3 | 3 | 3 |
| preactjs/preact | 3 | 6 | 3 | 5 |
| burntsushi/ripgrep | 14 | 12 | 12 | 10 |
| jqlang/jq | 8 | 10 | 18 | 13 |
| caddyserver/caddy | 12 | 6 | 11 | 8 |
| fmtlib/fmt | 15 | 10 | 16 | 8 |
| tokio-rs/tokio | 10 | 10 | 15 | 23 |
| redis/redis | 9 | 7 | 13 | 8 |
| rubocop/rubocop | 6 | 4 | 12 | 8 |
| briannesbitt/carbon | 14 | 17 | 10 | 15 |
| django/django | 10 | 7 | 7 | 9 |
| laravel/framework | 8 | 10 | 6 | 4 |
| sympy/sympy | 11 | 3 | 2 | 4 |
| apache/lucene | 5 | 8 | 15 | 4 |
| **合计** | 195 | 160 | 198 | 179 |

## 文本搜索与文件定位

单元格为“文本搜索/过滤子命令数 / 文件定位子命令数”。

| 仓库 | plain | 1024 | 2048 | 4096 |
| --- | ---: | ---: | ---: | ---: |
| axios/axios | 4/0 | 4/0 | 5/1 | 7/0 |
| psf/requests | 7/1 | 6/0 | 12/3 | 4/0 |
| gin-gonic/gin | 13/2 | 8/1 | 6/2 | 10/2 |
| pallets/flask | 4/1 | 3/0 | 2/0 | 4/0 |
| sharkdp/bat | 31/5 | 20/4 | 27/2 | 30/7 |
| jekyll/jekyll | 10/1 | 8/0 | 5/0 | 5/0 |
| google/gson | 5/1 | 4/2 | 2/1 | 3/0 |
| preactjs/preact | 3/0 | 6/1 | 3/0 | 5/2 |
| burntsushi/ripgrep | 13/5 | 12/0 | 11/2 | 12/1 |
| jqlang/jq | 8/1 | 12/0 | 20/1 | 13/4 |
| caddyserver/caddy | 14/1 | 8/0 | 16/0 | 10/0 |
| fmtlib/fmt | 15/3 | 10/2 | 19/6 | 8/2 |
| tokio-rs/tokio | 10/2 | 10/4 | 16/2 | 29/2 |
| redis/redis | 11/0 | 9/0 | 14/0 | 11/0 |
| rubocop/rubocop | 7/0 | 4/0 | 12/0 | 8/1 |
| briannesbitt/carbon | 14/3 | 19/2 | 11/1 | 16/2 |
| django/django | 12/0 | 8/0 | 8/4 | 10/1 |
| laravel/framework | 10/0 | 11/3 | 6/1 | 4/0 |
| sympy/sympy | 7/5 | 6/0 | 3/0 | 5/0 |
| apache/lucene | 3/2 | 8/2 | 12/6 | 2/2 |

## 计数与复核

- 按Bash语法树识别grep、rg等文本搜索/过滤与find、git ls-files等文件定位；排除普通读文件、ls目录浏览、Python等自定义搜索和RepoMap内部扫描。
- 条件分支或语法错误可能使已请求的命令没有执行，因此统计的是显式搜索请求，不是实际成功执行次数。
- 4条动作被语法解析器标记异常，已人工复核：Tokio 1024/2048各有1条grep请求因反引号转义错误而语法无效，仍各计1次搜索尝试；Rubocop plain/4096各有1条here-doc终止符错误，均未包含搜索，不计入搜索数。
- 每个仓库一个任务、每档一次有效运行；差异不能直接推广为所有任务的稳定效果。

[配对CSV](search-per-instance.csv) · [JSON统计](search-per-instance.json) · [解析异常复核](search-parse-review.json) · [全部预算实验](final-summary.md)
