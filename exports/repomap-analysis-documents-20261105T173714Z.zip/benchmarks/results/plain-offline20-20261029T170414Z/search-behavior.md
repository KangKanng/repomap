# RepoMap 是否减少搜索：已有20条任务的统计

按可明确识别的Shell搜索请求统计，本轮整体没有减少。主口径使用每组20条最终轨迹，RepoMap首次Ripgrep失败尝试另计。没有新增模型调用。

## 汇总

| 指标 | RepoMap | plain | RepoMap相对变化 |
| --- | ---: | ---: | ---: |
| 文本搜索/过滤子命令 | 221 | 203 | +8.9% |
| 文件定位子命令 | 39 | 25 | +56.0% |
| 搜索子命令合计 | 260 | 228 | +14.0% |
| 包含搜索的Bash请求 | 206 | 191 | +7.9% |
| 前5次模型调用中的搜索子命令 | 108 | 89 | +21.3% |
| 每题平均搜索子命令 | 13.00 | 11.40 | +14.0% |
| 搜索Bash请求/全部Bash动作 | 34.51% | 37.45% | -2.95个百分点 |

20条任务中，搜索子命令减少10条、增加10条、相同0条。搜索请求占全部Bash动作的比例较低，但总搜索次数较高，两种口径不能混淆。

排除推理镜像不同的Gson、Tokio后，其余18条搜索子命令为RepoMap 216、plain 206；包含搜索的Bash请求为173和172。

包含RepoMap失败重试在内的全部尝试：RepoMap 273个搜索子命令、216个搜索Bash请求；plain仍为228和191。

## 逐任务对齐

| 仓库 | RepoMap搜索子命令 | plain搜索子命令 | 差值R−P | RepoMap搜索请求 | plain搜索请求 |
| --- | ---: | ---: | ---: | ---: | ---: |
| gin-gonic/gin | 4 | 5 | -1 | 4 | 5 |
| fmtlib/fmt | 27 | 14 | +13 | 21 | 13 |
| google/gson | 5 | 9 | -4 | 3 | 9 |
| axios/axios | 3 | 9 | -6 | 3 | 6 |
| jekyll/jekyll | 10 | 7 | +3 | 9 | 6 |
| burntsushi/ripgrep | 19 | 11 | +8 | 13 | 9 |
| sharkdp/bat | 24 | 28 | -4 | 19 | 24 |
| preactjs/preact | 13 | 21 | -8 | 8 | 20 |
| briannesbitt/carbon | 19 | 21 | -2 | 17 | 13 |
| caddyserver/caddy | 6 | 12 | -6 | 6 | 9 |
| jqlang/jq | 13 | 11 | +2 | 10 | 9 |
| tokio-rs/tokio | 39 | 13 | +26 | 30 | 10 |
| redis/redis | 5 | 10 | -5 | 4 | 7 |
| rubocop/rubocop | 9 | 8 | +1 | 9 | 6 |
| laravel/framework | 9 | 3 | +6 | 9 | 3 |
| apache/lucene | 26 | 20 | +6 | 18 | 17 |
| django/django | 15 | 8 | +7 | 12 | 7 |
| pallets/flask | 3 | 4 | -1 | 2 | 4 |
| psf/requests | 6 | 5 | +1 | 6 | 5 |
| sympy/sympy | 5 | 9 | -4 | 3 | 9 |

## 计数口径与限制

1. 主口径为两组各20条最终轨迹，排除RepoMap的Ripgrep首次失败尝试；所有41次尝试另列。
2. 用Tree-sitter Bash语法树识别command节点，不按字符串中是否出现grep计数；注释、echo字符串、here-doc脚本文本不会自动算作已请求的搜索。
3. 文本搜索/过滤计grep、egrep、fgrep、rg、ag、ack、ugrep、zgrep、ripgrep、git grep；文件定位计find、fd、fdfind、locate、git ls-files和rg --files。
4. 每个搜索子命令计一次；同一Bash动作含多次搜索会分别计数。搜索Bash请求数是至少包含一个搜索子命令的动作数，一条动作只计一次。
5. 计数描述模型显式请求的命令，不保证条件分支或管道中的每个子命令实际执行，也不把已保存工具结果视为每个子命令的独立执行证据。
6. 文本搜索包括对日志、管道输出和文件名列表的过滤，不等同于只搜索仓库源码；不含Python/Ruby等自定义脚本搜索、程序内部搜索、ls目录浏览、普通读文件或RepoMap内部扫描。
7. 排除target/路径下待修复的rg项目二进制调用，避免把Ripgrep功能测试计为代码搜索。
8. 首5次调用按轨迹中的收费模型响应序号计算，包含格式错误响应；两组每条任务均至少有5次模型调用。
9. 一条plain jq动作存在未闭合引号，Bash解析器标记错误；已人工检查，该动作不含搜索命令，对搜索计数无影响。
10. 两轮为历史单次运行，Gson和Tokio推理镜像不同，不能据此确定地图对搜索量的因果影响；另提供排除这两条的18任务统计。

## 数据与复核

- [逐任务CSV](search-behavior.csv)
- [完整统计JSON](search-behavior.json)
- [搜索命令语法片段审计](search-behavior-audit.json)：原轨迹路径、消息/动作索引、子命令片段及动作SHA-256。
- [其他补充指标](additional-metrics.md)
- [按仓库源码长度分组的搜索统计](search-by-size.md)
