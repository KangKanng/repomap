# RepoMap 分析文档合集

包含此前列出的11份Markdown分析文档，保留项目内相对目录结构。

| 文档 | 内容 |
| --- | --- |
| [historical-map-quality-results.md](docs/historical-map-quality-results.md) | 最新历史地图质量回溯结果 |
| [summary.md](benchmarks/results/map-quality-history-20261105/summary.md) | 地图质量逐任务明细 |
| [once-implementation-and-case-analysis.md](docs/once-implementation-and-case-analysis.md) | Once实现与逐条分析 |
| [map-quality-evaluation.md](docs/map-quality-evaluation.md) | 实验A评测方法 |
| [experiment-results.md](docs/experiment-results.md) | 完整实验结果汇总，once部分为阶段快照 |
| [final-summary.md](benchmarks/results/budget-sweep-20261102T035731Z/final-summary.md) | 预算实验最终总结 |
| [search-per-instance.md](benchmarks/results/budget-sweep-20261102T035731Z/search-per-instance.md) | 预算实验逐条搜索对比 |
| [search-result-analysis.md](benchmarks/results/budget-sweep-20261102T035731Z/search-result-analysis.md) | 搜索量变化原因分析 |
| [search-behavior.md](benchmarks/results/plain-offline20-20261029T170414Z/search-behavior.md) | 早期RepoMap与plain搜索对比 |
| [search-by-size.md](benchmarks/results/plain-offline20-20261029T170414Z/search-by-size.md) | 按仓库长度统计搜索行为 |
| [additional-metrics.md](benchmarks/results/plain-offline20-20261029T170414Z/additional-metrics.md) | 补充指标分析 |

本包仅包含上述分析文档。文档中指向代码、轨迹、JSON、CSV、逐任务证据或其他材料的链接需在原项目中查看。

当前地图质量评测已完成文件召回，其余四项待标注。
