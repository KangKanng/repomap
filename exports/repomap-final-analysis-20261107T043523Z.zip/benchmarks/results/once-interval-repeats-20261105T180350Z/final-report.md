# Once / Interval：预算与重复实验报告

更新：2026-11-06T10:14:58.969389+00:00；推理 480/480，判题 480/480。
所有均值在完成前均为阶段性结果，不据此提前宣布收益。

主指标：Search Calls per Task；关键辅助：Target Localization Cost；必须同时检查：Resolved Rate。

| 策略 | 预算 | 有效推理 | 搜索数/任务 | 完整重复均值的标准差 | 定位前搜索（含定位动作） | 定位模型轮数 | 定位可观察覆盖 | Resolved Rate（通过/已判） | 已返回费用USD |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| once | 0 | 59/60 | 11.75 | 0.71 | 2.32 | 2.76 | 59/59 | 51/60 (85.0%) | 1.029844114756 |
| once | 1024 | 58/60 | 12.71 | 1.03 | 1.48 | 1.98 | 58/58 | 48/60 (80.0%) | 1.054877006022 |
| once | 2048 | 57/60 | 11.51 | N/A | 1.61 | 2.00 | 56/57 | 49/60 (81.7%) | 1.139674256566 |
| once | 4096 | 58/60 | 12.86 | 0.92 | 1.46 | 2.19 | 57/58 | 50/60 (83.3%) | 1.230611115128 |
| interval | 0 | 59/60 | 13.71 | 0.35 | 2.42 | 2.80 | 59/59 | 53/60 (88.3%) | 1.17069736748 |
| interval | 1024 | 60/60 | 12.05 | 0.87 | 1.80 | 2.22 | 59/60 | 54/60 (90.0%) | 3.14923423194 |
| interval | 2048 | 60/60 | 12.10 | 1.57 | 1.69 | 2.17 | 59/60 | 54/60 (90.0%) | 3.71514875328 |
| interval | 4096 | 60/60 | 11.43 | 0.90 | 1.42 | 1.78 | 59/60 | 53/60 (88.3%) | 3.86187688080 |

## Interval与Once直接对照

差值为interval减once；按任务及重复编号配对。基线调整值为两阶段各自相对plain的增量之差，不能消除全部时间或模型漂移影响。

| 预算 | 已配对/计划 | 每任务搜索差值 | 基线调整配对数 | 基线调整搜索差值 |
| --- | ---: | ---: | ---: | ---: |
| 0 | 58/60 | 1.64 | 0 | N/A |
| 1024 | 58/60 | -0.72 | 56 | -2.07 |
| 2048 | 57/60 | 0.44 | 55 | -0.62 |
| 4096 | 58/60 | -1.43 | 56 | -2.57 |

## 相对同阶段plain的配对比较

| 策略 | 预算 | 已配对/计划 | 每任务搜索差值 | 双方定位可观察 | 定位搜索差值 |
| --- | ---: | ---: | ---: | ---: | ---: |
| once | 1024 | 57/60 | 0.60 | 57/57 | -0.81 |
| once | 2048 | 56/60 | -0.59 | 55/56 | -0.58 |
| once | 4096 | 57/60 | 0.63 | 56/57 | -0.80 |
| interval | 1024 | 59/60 | -1.66 | 58/59 | -0.59 |
| interval | 2048 | 59/60 | -1.51 | 58/59 | -0.72 |
| interval | 4096 | 59/60 | -2.20 | 58/59 | -0.97 |

## 逐任务重复波动

| 策略 | 预算 | 任务 | 有效重复 | 搜索均值 | 重复间标准差 | 通过/已判 |
| --- | ---: | --- | ---: | ---: | ---: | ---: |
| once | 0 | apache__lucene-11760 | 3 | 10.67 | 8.96 | 3/3 |
| once | 0 | axios__axios-4731 | 3 | 6.00 | 6.08 | 2/3 |
| once | 0 | briannesbitt__carbon-2665 | 3 | 16.33 | 2.08 | 3/3 |
| once | 0 | burntsushi__ripgrep-2209 | 3 | 15.33 | 2.08 | 3/3 |
| once | 0 | caddyserver__caddy-4774 | 3 | 13.67 | 2.52 | 0/3 |
| once | 0 | django__django-10097 | 3 | 7.33 | 8.39 | 3/3 |
| once | 0 | fmtlib__fmt-1683 | 3 | 21.00 | 4.36 | 2/3 |
| once | 0 | gin-gonic__gin-1805 | 3 | 4.67 | 1.53 | 3/3 |
| once | 0 | google__gson-1014 | 3 | 6.00 | 1.00 | 3/3 |
| once | 0 | jekyll__jekyll-8047 | 3 | 7.33 | 1.15 | 3/3 |
| once | 0 | jqlang__jq-2235 | 3 | 17.67 | 9.50 | 3/3 |
| once | 0 | laravel__framework-46234 | 3 | 9.33 | 3.21 | 2/3 |
| once | 0 | pallets__flask-5014 | 3 | 4.00 | 1.00 | 3/3 |
| once | 0 | preactjs__preact-2757 | 3 | 10.33 | 1.15 | 3/3 |
| once | 0 | psf__requests-1142 | 3 | 19.33 | 7.77 | 3/3 |
| once | 0 | redis__redis-10068 | 3 | 5.00 | 2.00 | 3/3 |
| once | 0 | rubocop__rubocop-13362 | 3 | 9.33 | 2.52 | 3/3 |
| once | 0 | sharkdp__bat-1892 | 2 | 29.50 | 4.95 | 2/3 |
| once | 0 | sympy__sympy-11618 | 3 | 9.33 | 3.06 | 1/3 |
| once | 0 | tokio-rs__tokio-4384 | 3 | 18.67 | 5.86 | 3/3 |
| once | 1024 | apache__lucene-11760 | 3 | 10.67 | 4.93 | 3/3 |
| once | 1024 | axios__axios-4731 | 3 | 6.33 | 2.89 | 3/3 |
| once | 1024 | briannesbitt__carbon-2665 | 2 | 8.50 | 4.95 | 1/3 |
| once | 1024 | burntsushi__ripgrep-2209 | 3 | 18.00 | 4.36 | 3/3 |
| once | 1024 | caddyserver__caddy-4774 | 3 | 12.33 | 4.73 | 0/3 |
| once | 1024 | django__django-10097 | 3 | 10.33 | 3.06 | 3/3 |
| once | 1024 | fmtlib__fmt-1683 | 3 | 16.00 | 5.57 | 1/3 |
| once | 1024 | gin-gonic__gin-1805 | 3 | 9.67 | 2.52 | 3/3 |
| once | 1024 | google__gson-1014 | 3 | 5.33 | 0.58 | 3/3 |
| once | 1024 | jekyll__jekyll-8047 | 3 | 7.67 | 2.08 | 3/3 |
| once | 1024 | jqlang__jq-2235 | 3 | 9.00 | 1.00 | 3/3 |
| once | 1024 | laravel__framework-46234 | 3 | 12.67 | 8.14 | 2/3 |
| once | 1024 | pallets__flask-5014 | 3 | 3.33 | 1.53 | 3/3 |
| once | 1024 | preactjs__preact-2757 | 3 | 9.00 | 2.65 | 3/3 |
| once | 1024 | psf__requests-1142 | 3 | 16.33 | 6.66 | 3/3 |
| once | 1024 | redis__redis-10068 | 3 | 6.00 | 1.00 | 3/3 |
| once | 1024 | rubocop__rubocop-13362 | 2 | 9.50 | 2.12 | 2/3 |
| once | 1024 | sharkdp__bat-1892 | 3 | 34.67 | 2.52 | 3/3 |
| once | 1024 | sympy__sympy-11618 | 3 | 18.00 | 5.20 | 0/3 |
| once | 1024 | tokio-rs__tokio-4384 | 3 | 28.33 | 9.29 | 3/3 |
| once | 2048 | apache__lucene-11760 | 2 | 10.50 | 2.12 | 2/3 |
| once | 2048 | axios__axios-4731 | 3 | 6.00 | 1.00 | 2/3 |
| once | 2048 | briannesbitt__carbon-2665 | 3 | 14.33 | 2.08 | 3/3 |
| once | 2048 | burntsushi__ripgrep-2209 | 3 | 14.67 | 1.53 | 3/3 |
| once | 2048 | caddyserver__caddy-4774 | 3 | 10.67 | 4.62 | 2/3 |
| once | 2048 | django__django-10097 | 3 | 12.67 | 8.39 | 3/3 |
| once | 2048 | fmtlib__fmt-1683 | 3 | 15.00 | 2.65 | 1/3 |
| once | 2048 | gin-gonic__gin-1805 | 3 | 6.67 | 0.58 | 3/3 |
| once | 2048 | google__gson-1014 | 3 | 3.67 | 2.52 | 3/3 |
| once | 2048 | jekyll__jekyll-8047 | 3 | 5.00 | 1.00 | 3/3 |
| once | 2048 | jqlang__jq-2235 | 3 | 11.00 | 3.61 | 3/3 |
| once | 2048 | laravel__framework-46234 | 3 | 12.67 | 3.51 | 2/3 |
| once | 2048 | pallets__flask-5014 | 3 | 2.00 | 0.00 | 3/3 |
| once | 2048 | preactjs__preact-2757 | 2 | 8.50 | 2.12 | 2/3 |
| once | 2048 | psf__requests-1142 | 3 | 11.67 | 6.03 | 3/3 |
| once | 2048 | redis__redis-10068 | 3 | 9.00 | 5.00 | 3/3 |
| once | 2048 | rubocop__rubocop-13362 | 3 | 11.67 | 1.53 | 3/3 |
| once | 2048 | sharkdp__bat-1892 | 3 | 26.00 | 2.65 | 3/3 |
| once | 2048 | sympy__sympy-11618 | 3 | 17.67 | 9.02 | 0/3 |
| once | 2048 | tokio-rs__tokio-4384 | 2 | 23.50 | 0.71 | 2/3 |
| once | 4096 | apache__lucene-11760 | 3 | 16.00 | 4.36 | 3/3 |
| once | 4096 | axios__axios-4731 | 3 | 5.00 | 1.00 | 2/3 |
| once | 4096 | briannesbitt__carbon-2665 | 3 | 16.00 | 3.61 | 3/3 |
| once | 4096 | burntsushi__ripgrep-2209 | 3 | 16.33 | 5.51 | 3/3 |
| once | 4096 | caddyserver__caddy-4774 | 2 | 25.00 | 11.31 | 2/3 |
| once | 4096 | django__django-10097 | 3 | 12.33 | 5.13 | 3/3 |
| once | 4096 | fmtlib__fmt-1683 | 3 | 14.67 | 4.73 | 3/3 |
| once | 4096 | gin-gonic__gin-1805 | 3 | 12.33 | 5.86 | 2/3 |
| once | 4096 | google__gson-1014 | 3 | 3.00 | 1.73 | 2/3 |
| once | 4096 | jekyll__jekyll-8047 | 3 | 7.33 | 3.21 | 3/3 |
| once | 4096 | jqlang__jq-2235 | 2 | 7.50 | 0.71 | 2/3 |
| once | 4096 | laravel__framework-46234 | 3 | 7.67 | 4.62 | 0/3 |
| once | 4096 | pallets__flask-5014 | 3 | 3.67 | 2.08 | 3/3 |
| once | 4096 | preactjs__preact-2757 | 3 | 8.33 | 1.15 | 3/3 |
| once | 4096 | psf__requests-1142 | 3 | 14.67 | 4.73 | 3/3 |
| once | 4096 | redis__redis-10068 | 3 | 5.33 | 1.53 | 3/3 |
| once | 4096 | rubocop__rubocop-13362 | 3 | 10.00 | 3.00 | 3/3 |
| once | 4096 | sharkdp__bat-1892 | 3 | 33.00 | 5.20 | 3/3 |
| once | 4096 | sympy__sympy-11618 | 3 | 9.00 | 6.08 | 1/3 |
| once | 4096 | tokio-rs__tokio-4384 | 3 | 32.33 | 4.04 | 3/3 |
| interval | 0 | apache__lucene-11760 | 3 | 21.33 | 20.50 | 3/3 |
| interval | 0 | axios__axios-4731 | 3 | 6.00 | 0.00 | 3/3 |
| interval | 0 | briannesbitt__carbon-2665 | 3 | 14.00 | 3.46 | 3/3 |
| interval | 0 | burntsushi__ripgrep-2209 | 3 | 13.33 | 3.51 | 3/3 |
| interval | 0 | caddyserver__caddy-4774 | 3 | 15.33 | 4.73 | 3/3 |
| interval | 0 | django__django-10097 | 2 | 12.00 | 7.07 | 2/3 |
| interval | 0 | fmtlib__fmt-1683 | 3 | 15.33 | 8.50 | 1/3 |
| interval | 0 | gin-gonic__gin-1805 | 3 | 7.33 | 3.51 | 3/3 |
| interval | 0 | google__gson-1014 | 3 | 7.00 | 1.00 | 3/3 |
| interval | 0 | jekyll__jekyll-8047 | 3 | 8.67 | 0.58 | 3/3 |
| interval | 0 | jqlang__jq-2235 | 3 | 17.00 | 7.81 | 3/3 |
| interval | 0 | laravel__framework-46234 | 3 | 8.33 | 3.21 | 2/3 |
| interval | 0 | pallets__flask-5014 | 3 | 4.00 | 1.00 | 3/3 |
| interval | 0 | preactjs__preact-2757 | 3 | 9.33 | 2.08 | 3/3 |
| interval | 0 | psf__requests-1142 | 3 | 14.67 | 4.51 | 3/3 |
| interval | 0 | redis__redis-10068 | 3 | 11.33 | 7.57 | 3/3 |
| interval | 0 | rubocop__rubocop-13362 | 3 | 11.33 | 3.06 | 3/3 |
| interval | 0 | sharkdp__bat-1892 | 3 | 33.33 | 12.10 | 3/3 |
| interval | 0 | sympy__sympy-11618 | 3 | 18.33 | 9.24 | 0/3 |
| interval | 0 | tokio-rs__tokio-4384 | 3 | 25.67 | 18.72 | 3/3 |
| interval | 1024 | apache__lucene-11760 | 3 | 15.00 | 5.57 | 3/3 |
| interval | 1024 | axios__axios-4731 | 3 | 6.00 | 2.65 | 3/3 |
| interval | 1024 | briannesbitt__carbon-2665 | 3 | 20.33 | 4.93 | 3/3 |
| interval | 1024 | burntsushi__ripgrep-2209 | 3 | 14.33 | 5.69 | 3/3 |
| interval | 1024 | caddyserver__caddy-4774 | 3 | 12.67 | 3.51 | 0/3 |
| interval | 1024 | django__django-10097 | 3 | 5.67 | 5.51 | 3/3 |
| interval | 1024 | fmtlib__fmt-1683 | 3 | 16.33 | 6.11 | 3/3 |
| interval | 1024 | gin-gonic__gin-1805 | 3 | 8.67 | 4.04 | 3/3 |
| interval | 1024 | google__gson-1014 | 3 | 7.67 | 5.51 | 3/3 |
| interval | 1024 | jekyll__jekyll-8047 | 3 | 5.00 | 1.00 | 3/3 |
| interval | 1024 | jqlang__jq-2235 | 3 | 12.67 | 4.73 | 3/3 |
| interval | 1024 | laravel__framework-46234 | 3 | 9.00 | 2.65 | 2/3 |
| interval | 1024 | pallets__flask-5014 | 3 | 2.67 | 0.58 | 3/3 |
| interval | 1024 | preactjs__preact-2757 | 3 | 6.33 | 0.58 | 3/3 |
| interval | 1024 | psf__requests-1142 | 3 | 10.67 | 6.03 | 3/3 |
| interval | 1024 | redis__redis-10068 | 3 | 7.67 | 1.15 | 3/3 |
| interval | 1024 | rubocop__rubocop-13362 | 3 | 10.00 | 2.00 | 3/3 |
| interval | 1024 | sharkdp__bat-1892 | 3 | 29.00 | 7.81 | 3/3 |
| interval | 1024 | sympy__sympy-11618 | 3 | 13.00 | 3.00 | 1/3 |
| interval | 1024 | tokio-rs__tokio-4384 | 3 | 28.33 | 5.51 | 3/3 |
| interval | 2048 | apache__lucene-11760 | 3 | 16.00 | 2.65 | 3/3 |
| interval | 2048 | axios__axios-4731 | 3 | 5.67 | 3.21 | 3/3 |
| interval | 2048 | briannesbitt__carbon-2665 | 3 | 13.67 | 4.62 | 3/3 |
| interval | 2048 | burntsushi__ripgrep-2209 | 3 | 14.67 | 4.04 | 3/3 |
| interval | 2048 | caddyserver__caddy-4774 | 3 | 14.33 | 5.13 | 2/3 |
| interval | 2048 | django__django-10097 | 3 | 16.00 | 13.23 | 3/3 |
| interval | 2048 | fmtlib__fmt-1683 | 3 | 12.67 | 2.31 | 2/3 |
| interval | 2048 | gin-gonic__gin-1805 | 3 | 9.33 | 2.08 | 3/3 |
| interval | 2048 | google__gson-1014 | 3 | 4.67 | 0.58 | 3/3 |
| interval | 2048 | jekyll__jekyll-8047 | 3 | 7.67 | 1.15 | 3/3 |
| interval | 2048 | jqlang__jq-2235 | 3 | 18.33 | 7.23 | 3/3 |
| interval | 2048 | laravel__framework-46234 | 3 | 8.00 | 3.46 | 1/3 |
| interval | 2048 | pallets__flask-5014 | 3 | 2.67 | 1.15 | 3/3 |
| interval | 2048 | preactjs__preact-2757 | 3 | 8.33 | 2.08 | 3/3 |
| interval | 2048 | psf__requests-1142 | 3 | 8.33 | 2.31 | 3/3 |
| interval | 2048 | redis__redis-10068 | 3 | 8.00 | 2.00 | 3/3 |
| interval | 2048 | rubocop__rubocop-13362 | 3 | 8.33 | 4.16 | 3/3 |
| interval | 2048 | sharkdp__bat-1892 | 3 | 28.67 | 3.79 | 3/3 |
| interval | 2048 | sympy__sympy-11618 | 3 | 13.00 | 6.08 | 1/3 |
| interval | 2048 | tokio-rs__tokio-4384 | 3 | 23.67 | 2.08 | 3/3 |
| interval | 4096 | apache__lucene-11760 | 3 | 18.00 | 9.64 | 3/3 |
| interval | 4096 | axios__axios-4731 | 3 | 3.33 | 1.15 | 3/3 |
| interval | 4096 | briannesbitt__carbon-2665 | 3 | 15.00 | 7.81 | 3/3 |
| interval | 4096 | burntsushi__ripgrep-2209 | 3 | 13.00 | 6.08 | 3/3 |
| interval | 4096 | caddyserver__caddy-4774 | 3 | 13.00 | 1.73 | 1/3 |
| interval | 4096 | django__django-10097 | 3 | 4.67 | 2.08 | 3/3 |
| interval | 4096 | fmtlib__fmt-1683 | 3 | 16.33 | 2.08 | 2/3 |
| interval | 4096 | gin-gonic__gin-1805 | 3 | 8.33 | 5.51 | 3/3 |
| interval | 4096 | google__gson-1014 | 3 | 5.33 | 1.53 | 3/3 |
| interval | 4096 | jekyll__jekyll-8047 | 3 | 5.00 | 1.00 | 3/3 |
| interval | 4096 | jqlang__jq-2235 | 3 | 16.33 | 4.73 | 3/3 |
| interval | 4096 | laravel__framework-46234 | 3 | 10.00 | 5.29 | 1/3 |
| interval | 4096 | pallets__flask-5014 | 3 | 1.33 | 0.58 | 3/3 |
| interval | 4096 | preactjs__preact-2757 | 3 | 7.67 | 5.51 | 3/3 |
| interval | 4096 | psf__requests-1142 | 3 | 10.33 | 4.51 | 3/3 |
| interval | 4096 | redis__redis-10068 | 3 | 13.00 | 4.58 | 3/3 |
| interval | 4096 | rubocop__rubocop-13362 | 3 | 11.67 | 3.51 | 3/3 |
| interval | 4096 | sharkdp__bat-1892 | 3 | 30.67 | 5.03 | 3/3 |
| interval | 4096 | sympy__sympy-11618 | 3 | 9.33 | 1.15 | 1/3 |
| interval | 4096 | tokio-rs__tokio-4384 | 3 | 16.33 | 4.73 | 3/3 |

## 解释边界

- Search Calls counts explicit Bash search subcommands, not model calls or necessarily executed branches.
- Localization is an explicit read with successful model-visible output matching unique baseline code near official hunks.
- Unknown script-based reads, alternate correct fix paths, and undetected reads remain not_observed, never zero.
- Localization costs include the full locating action; compare observed coverage and paired coverage alongside means.
- Intervals use recent-six context; once uses raw task only. Their contrast is a combined policy contrast.
- Sequential phases can be confounded by provider changes; each phase includes newly repeated plain controls.
- Three repeats quantify observed variation but do not prove success-rate noninferiority.
- Partial averages cover completed valid inferences and are provisional; invalid/unfinished runs are not zero-search wins.

[完整JSON](repeat-report.json) · [逐次CSV](repeat-trials.csv) · [固定实验协议](protocol.json)
