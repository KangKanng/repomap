"""Offline integrity audit and task-cluster analysis of the 480 completed runs."""

import argparse
import copy
import csv
import hashlib
import json
import statistics
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path

import numpy as np
import tiktoken

PROJECT = next(p for p in Path(__file__).resolve().parents if (p / "src/mini_swe_repomap").is_dir())
sys.path.insert(0, str(PROJECT / "scripts"))
from localization_metrics import localization  # noqa: E402
from map_quality_metrics import parse_map  # noqa: E402
from search_metrics import SearchCounter  # noqa: E402


def load(path):
    return json.loads(path.read_text())


def digest(data):
    return hashlib.sha256(data).hexdigest()


def mean(values):
    return statistics.mean(values) if values else None


def observed(row):
    return row["localization"]["status"] == "observed_explicit_read"


def effect(pairs, getter, *, scale=1, bootstraps=10000):
    """Resample whole task clusters; repetitions within a task stay together."""
    grouped = defaultdict(list)
    for baseline, treatment in pairs:
        before, after = getter(baseline), getter(treatment)
        if before is not None and after is not None:
            grouped[baseline["instance_id"]].append((float(before), float(after)))
    if not grouped:
        return {"pairs": 0, "tasks": 0, "delta_mean": None, "ci95": None}
    clusters = list(grouped.values())
    counts = np.array([len(c) for c in clusters], dtype=float)
    before_sums = np.array([sum(a for a, b in c) for c in clusters])
    deltas = np.array([sum(b - a for a, b in c) for c in clusters])
    rng = np.random.default_rng(20261107)
    choices = rng.integers(0, len(clusters), size=(bootstraps, len(clusters)))
    samples = deltas[choices].sum(axis=1) / counts[choices].sum(axis=1) * scale
    delta = float(deltas.sum() / counts.sum()) * scale
    before = float(before_sums.sum() / counts.sum()) * scale
    task_deltas = deltas / counts * scale
    return {
        "pairs": int(counts.sum()),
        "tasks": len(clusters),
        "baseline_mean": before,
        "treatment_mean": before + delta,
        "delta_mean": delta,
        "relative_change": delta / before if before else None,
        "ci95": np.quantile(samples, [0.025, 0.975]).tolist(),
        "equal_task_weight_delta": float(task_deltas.mean()),
        "task_fewer": int((task_deltas < -1e-12).sum()),
        "task_equal": int((abs(task_deltas) <= 1e-12).sum()),
        "task_more": int((task_deltas > 1e-12).sum()),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--run", type=Path, default=PROJECT / "benchmarks/results/once-interval-repeats-20261105T180350Z"
    )
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    root = args.run.resolve()
    output = (args.output or root / "final-analysis").resolve()
    output.mkdir(parents=True, exist_ok=True)
    source_path = root / "final-repeat-report.json"
    original = load(source_path)
    rows = copy.deepcopy(original["trials"])
    protocol = load(root / "protocol.json")
    references = load(root / "localization-reference.json")
    reference_dir = Path(references["source_reference"])
    gold = {p.stem: load(p) for p in reference_dir.glob("*.json")}
    targets = {iid: {f["map_path"] for f in r["official_patch_files"]} for iid, r in gold.items()}
    expected_images = {r["instance_id"]: r for r in load(root / "prepared/selection-pinned.json")}
    counter, encoding = SearchCounter(), tiktoken.get_encoding("cl100k_base")
    map_cache, all_models, cost_sources = {}, Counter(), Counter()
    checks, timeouts, no_test_results, responses, returned_cost = {}, [], [], 0, Decimal(0)
    records = {}
    for job in protocol["queue"]:
        for row in load(Path(job["directory"]) / "summary.json")["runs"]:
            records[(job["phase"], job["repeat"], row["budget"], row["instance_id"])] = row
    for index, row in enumerate(rows):
        key = (row["phase"], row["repeat"], row["budget"], row["instance_id"])
        key_text = ":".join(map(str, key))
        path = Path(row["trajectory"])
        raw = path.read_bytes()
        checks[f"trajectory_hash:{key_text}"] = digest(raw) == row["sha256"]
        data = json.loads(raw)
        messages = data["messages"]
        config = data["info"]["config"]
        repomap = config["agent"]["repomap"]
        checks[f"config:{key_text}"] = (
            repomap.get("refresh", "interval") == row["phase"]
            and repomap["map_tokens"] == row["budget"]
            and repomap["context_messages"] == (0 if row["phase"] == "once" else 6)
            and config["model"]["model_name"] == protocol["model"]
            and config["environment"]["image"] == expected_images[row["instance_id"]]["image"]
            and "--network=none" in config["environment"]["run_args"]
            and "--pull=never" in config["environment"]["run_args"]
        )
        counts, _ = counter.messages(messages)
        checks[f"search_counts:{key_text}"] = counts["search_commands"] == row["search_commands"]
        checks[f"localization:{key_text}"] = (
            localization(messages, references["instances"][row["instance_id"]]) == row["localization"]
        )
        charges, request_maps, calls = Decimal(0), [], 0
        for mi, message in enumerate(messages):
            if message.get("role") == "assistant":
                calls += 1
            extra = message.get("extra", {})
            if "cost" not in extra:
                continue
            responses += 1
            response = extra.get("response", {})
            source = extra.get("cost_source", "unknown")
            cost_sources[source] += 1
            usage = response.get("usage", {}) if isinstance(response, dict) else {}
            cost = Decimal(str(extra["cost"]))
            checks[f"billing:{key_text}:{mi}"] = (
                source.startswith("server:") and usage.get("cost") is not None and cost == Decimal(str(usage["cost"]))
            )
            charges += cost
            all_models[response.get("model", "unknown")] += 1
            snapshots = extra.get("request_repository_maps")
            checks[f"request_maps:{key_text}:{mi}"] = snapshots is not None and len(snapshots) == int(row["budget"] > 0)
            for snapshot in snapshots or []:
                sha, content = snapshot["sha256"], snapshot["content"]
                checks[f"map_hash:{sha}"] = digest(content.encode()) == sha
                if sha not in map_cache:
                    map_cache[sha] = {
                        "files": parse_map(content)["files"],
                        "tokens": len(encoding.encode(content, disallowed_special=())),
                    }
                checks[f"map_budget:{key_text}:{sha}"] = map_cache[sha]["tokens"] <= row["budget"]
                request_maps.append({"call": calls, "message_index": mi, "sha256": sha})
        checks[f"cost_total:{key_text}"] = charges == Decimal(row["server_cost_usd"])
        returned_cost += charges
        official_path = Path(row["evaluation_report"])
        official = load(official_path)
        single = official.get(row["instance_id"])
        if single is not None:
            checks[f"resolved:{key_text}"] = bool(single["resolved"]) == row["resolved"]
            if not single.get("tests_status"):
                no_test_results.append(
                    {"key": key, "repo": row["repo"], "official_report": str(official_path), "flags": single}
                )
        else:
            checks[f"empty_patch:{key_text}"] = (
                row["instance_id"] in official.get("empty_patch_ids", []) and not row["resolved"]
            )
        if request_maps:
            gold_paths = targets[row["instance_id"]]
            views = [map_cache[s["sha256"]]["files"] for s in request_maps]
            union = set().union(*views)
            first_hit_call = next((s["call"] for s, v in zip(request_maps, views, strict=True) if v & gold_paths), None)
            loc = row["localization"]
            first_localized_path_call = (
                next((s["call"] for s, v in zip(request_maps, views, strict=True) if loc.get("path") in v), None)
                if observed(row)
                else None
            )
            timing = (
                (
                    "before_or_same_call"
                    if first_localized_path_call is not None and first_localized_path_call <= loc["assistant_calls"]
                    else "after_localization"
                    if first_localized_path_call is not None
                    else "never_in_recorded_maps"
                )
                if observed(row)
                else "localization_unknown"
            )
            row["map_analysis"] = {
                "requests": len(request_maps),
                "unique_maps": len({s["sha256"] for s in request_maps}),
                "initial_sha256": request_maps[0]["sha256"],
                "final_sha256": request_maps[-1]["sha256"],
                "target_files": len(gold_paths),
                "initial_hit_files": sorted(views[0] & gold_paths),
                "final_hit_files": sorted(views[-1] & gold_paths),
                "union_hit_files": sorted(union & gold_paths),
                "initial_recall": len(views[0] & gold_paths) / len(gold_paths),
                "final_recall": len(views[-1] & gold_paths) / len(gold_paths),
                "union_recall": len(union & gold_paths) / len(gold_paths),
                "first_any_gold_visible_call": first_hit_call,
                "first_localized_path_visible_call": first_localized_path_call,
                "localized_path_visibility": timing,
            }
        if not row["run_valid"]:
            record = records[key]
            stamps = [m.get("extra", {}).get("timestamp") for m in messages if m.get("extra", {}).get("timestamp")]
            finish = datetime.fromisoformat(record["finished_at"]).timestamp()
            timeouts.append(
                {
                    "key": key,
                    "repo": row["repo"],
                    "elapsed_seconds": record["elapsed_seconds"],
                    "recorded_searches": row["search_commands"],
                    "recorded_returned_cost_usd": str(charges),
                    "last_saved_role": messages[-1]["role"],
                    "seconds_without_new_saved_message_before_kill": finish - max(stamps),
                    "pending_request_charge_unknown": True,
                    "trajectory": str(path),
                }
            )
        if (index + 1) % 80 == 0:
            print("AUDITED", index + 1, "/", len(rows), flush=True)
    checks["480_trials"] = len(rows) == 480
    checks["471_valid_9_timeout"] = sum(r["run_valid"] for r in rows) == 471 and len(timeouts) == 9
    checks["single_actual_model"] = set(all_models) == {"deepseek/deepseek-v4.1-flash-1017"}
    for relative, sha in protocol["source_hashes"].items():
        checks[f"frozen_source:{relative}"] = digest((PROJECT / relative).read_bytes()) == sha
    audit_files = [p for job in protocol["queue"] for p in Path(job["directory"]).rglob("network-audit.jsonl")]
    grading_audits = [
        json.loads(line) for path in audit_files for line in path.read_text().splitlines() if line.strip()
    ]
    checks["grading_containers"] = len(grading_audits) == 471 and all(
        r["network_mode"] == "none" for r in grading_audits
    )
    failures = [key for key, value in checks.items() if not value]
    if failures:
        raise RuntimeError(f"Integrity audit failed: {failures[:10]}")
    lookup = {(r["phase"], r["repeat"], r["budget"], r["instance_id"]): r for r in rows}
    aggregates, comparisons, policy = [], [], []
    for phase in ("once", "interval"):
        for budget in (0, 1024, 2048, 4096):
            sample = [r for r in rows if r["phase"] == phase and r["budget"] == budget]
            valid = [r for r in sample if r["run_valid"]]
            visible = [r for r in valid if observed(r)]
            prompt = sum(r["prompt_tokens"] for r in sample)
            cached = sum(r["cached_prompt_tokens"] for r in sample)
            aggregate = {
                "phase": phase,
                "budget": budget,
                "planned": len(sample),
                "valid": len(valid),
                "resolved": sum(r["resolved"] for r in sample),
                "timeouts": len(sample) - len(valid),
                "valid_only_resolved": sum(r["resolved"] for r in valid),
                "search_mean": mean([r["search_commands"] for r in valid]),
                "observed_all_attempt_search_mean": mean([r["search_commands"] for r in sample]),
                "localization_n": len(visible),
                "localization_search_mean": mean(
                    [r["localization"]["search_commands_through_action"] for r in visible]
                ),
                "localization_calls_mean": mean([r["localization"]["assistant_calls"] for r in visible]),
                "localization_n_including_timeouts": sum(observed(r) for r in sample),
                "localization_search_mean_including_timeouts": mean(
                    [r["localization"]["search_commands_through_action"] for r in sample if observed(r)]
                ),
                "prompt_tokens": prompt,
                "cached_prompt_fraction": cached / prompt,
                "completion_tokens": sum(r["completion_tokens"] for r in sample),
                "api_calls": sum(r["api_calls"] for r in sample),
                "returned_cost_usd": str(sum((Decimal(r["server_cost_usd"]) for r in sample), Decimal(0))),
                "repeat_resolved": [
                    sum(r["resolved"] for r in sample if r["repeat"] == repeat) for repeat in (1, 2, 3)
                ],
            }
            if budget:
                aggregate["map_quality"] = {
                    key: mean([r["map_analysis"][key] for r in sample])
                    for key in ("initial_recall", "final_recall", "union_recall", "unique_maps")
                }
                aggregate["map_timing"] = dict(Counter(r["map_analysis"]["localized_path_visibility"] for r in visible))
                repeat_hashes = defaultdict(set)
                for r in sample:
                    repeat_hashes[r["instance_id"]].add(r["map_analysis"]["initial_sha256"])
                aggregate["initial_map_stable_tasks"] = sum(len(hashes) == 1 for hashes in repeat_hashes.values())
            aggregates.append(aggregate)
            if not budget:
                continue
            all_pairs = [(lookup[(phase, r["repeat"], 0, r["instance_id"])], r) for r in sample]
            pairs = [(a, b) for a, b in all_pairs if a["run_valid"] and b["run_valid"]]
            loc_pairs = [(a, b) for a, b in pairs if observed(a) and observed(b)]
            comparison = {
                "phase": phase,
                "budget": budget,
                "search": effect(pairs, lambda r: r["search_commands"]),
                "localization": effect(loc_pairs, lambda r: r["localization"]["search_commands_through_action"]),
                "resolved_all": effect(all_pairs, lambda r: int(r["resolved"]), scale=100),
                "resolved_valid_pairs": effect(pairs, lambda r: int(r["resolved"]), scale=100),
                "valid_pair_success_counts": [
                    sum(a["resolved"] for a, b in pairs),
                    sum(b["resolved"] for a, b in pairs),
                ],
                "stage_decomposition": {
                    "pairs": len(loc_pairs),
                    "through_localization_delta_sum": sum(
                        b["localization"]["search_commands_through_action"]
                        - a["localization"]["search_commands_through_action"]
                        for a, b in loc_pairs
                    ),
                    "total_search_delta_sum": sum(b["search_commands"] - a["search_commands"] for a, b in loc_pairs),
                },
                "repeat_search_delta": [
                    mean([b["search_commands"] - a["search_commands"] for a, b in pairs if b["repeat"] == repeat])
                    for repeat in (1, 2, 3)
                ],
            }
            stage = comparison["stage_decomposition"]
            stage["after_localization_delta_sum"] = (
                stage["total_search_delta_sum"] - stage["through_localization_delta_sum"]
            )
            comparison["initial_hit_subgroups"] = {}
            for hit in (False, True):
                subgroup = [(a, b) for a, b in pairs if bool(b["map_analysis"]["initial_hit_files"]) == hit]
                comparison["initial_hit_subgroups"][str(hit)] = {
                    "pairs": len(subgroup),
                    "tasks": len({a["instance_id"] for a, b in subgroup}),
                    "search_delta_sum": sum(b["search_commands"] - a["search_commands"] for a, b in subgroup),
                    "localization": effect(
                        [(a, b) for a, b in subgroup if observed(a) and observed(b)],
                        lambda r: r["localization"]["search_commands_through_action"],
                    ),
                }
            comparison["task_contributions"] = [
                {
                    "instance_id": iid,
                    "repo": sub[0][0]["repo"],
                    "pairs": len(sub),
                    "search_delta_sum": sum(b["search_commands"] - a["search_commands"] for a, b in sub),
                }
                for iid in sorted({a["instance_id"] for a, b in pairs})
                if (sub := [(a, b) for a, b in pairs if a["instance_id"] == iid])
            ]
            comparisons.append(comparison)
    for budget in (0, 1024, 2048, 4096):
        all_pairs = [
            (lookup[("once", r["repeat"], budget, r["instance_id"])], r)
            for r in rows
            if r["phase"] == "interval" and r["budget"] == budget
        ]
        pairs = [(a, b) for a, b in all_pairs if a["run_valid"] and b["run_valid"]]
        adjusted = []
        for a, b in pairs:
            pa = lookup[("once", a["repeat"], 0, a["instance_id"])]
            pb = lookup[("interval", b["repeat"], 0, b["instance_id"])]
            if budget and pa["run_valid"] and pb["run_valid"]:
                left = dict(a, adjusted_search=a["search_commands"] - pa["search_commands"])
                right = dict(b, adjusted_search=b["search_commands"] - pb["search_commands"])
                adjusted.append((left, right))
        policy.append(
            {
                "budget": budget,
                "raw_search": effect(pairs, lambda r: r["search_commands"]),
                "baseline_adjusted_search": effect(adjusted, lambda r: r["adjusted_search"]),
                "resolved_all": effect(all_pairs, lambda r: int(r["resolved"]), scale=100),
            }
        )
    ordered = sorted({(r["source_lines"], r["instance_id"], r["repo"]) for r in rows})
    size_groups = []
    for offset in range(0, 20, 5):
        selected = ordered[offset : offset + 5]
        ids = {iid for _, iid, _ in selected}
        for c in comparisons:
            sample = [
                r for r in rows if r["phase"] == c["phase"] and r["budget"] == c["budget"] and r["instance_id"] in ids
            ]
            pairs = [
                (lookup[(r["phase"], r["repeat"], 0, r["instance_id"])], r)
                for r in sample
                if r["run_valid"] and lookup[(r["phase"], r["repeat"], 0, r["instance_id"])]["run_valid"]
            ]
            size_groups.append(
                {
                    "source_lines_min": selected[0][0],
                    "source_lines_max": selected[-1][0],
                    "phase": c["phase"],
                    "budget": c["budget"],
                    "pairs": len(pairs),
                    "search_delta_mean": mean([b["search_commands"] - a["search_commands"] for a, b in pairs]),
                    "resolved": sum(r["resolved"] for r in sample),
                    "planned": len(sample),
                    "baseline_resolved": sum(
                        lookup[(r["phase"], r["repeat"], 0, r["instance_id"])]["resolved"] for r in sample
                    ),
                }
            )
    review = []
    retry_root = output / "gson-evaluation-retry"
    for path in retry_root.rglob("report.json") if retry_root.exists() else []:
        data = load(path)
        if "google__gson-1014" in data:
            original_row = next(
                r
                for r in rows
                if r["phase"] == "once" and r["repeat"] == 2 and r["budget"] == 4096 and r["repo"] == "google/gson"
            )
            predictions = load(retry_root / "predictions.json")
            patch = json.loads(Path(original_row["trajectory"]).read_text())["info"]["submission"]
            assert next(p["model_patch"] for p in predictions if p["instance_id"] == "google__gson-1014") == patch
            review.append(
                {
                    "case": ["once", 2, 4096, "google__gson-1014"],
                    "original_resolved": original_row["resolved"],
                    "retry_resolved": data["google__gson-1014"]["resolved"],
                    "report": str(path),
                    "patch_sha256": digest(patch.encode()),
                    "reason": "Original Maven daemon connection timeout; target test not executed, patch cleanly applied.",
                    "original_data_preserved": True,
                    "model_calls": 0,
                }
            )
    result = {
        "created_at": datetime.now(timezone.utc).isoformat(),
        "source": str(source_path),
        "source_sha256": digest(source_path.read_bytes()),
        "completed_attempts": len(rows),
        "valid_submissions": sum(r["run_valid"] for r in rows),
        "raw_resolved": sum(r["resolved"] for r in rows),
        "grading_containers": len(grading_audits),
        "billed_responses": responses,
        "returned_cost_usd": str(returned_cost),
        "actual_models": dict(all_models),
        "cost_sources": dict(cost_sources),
        "model_calls_for_analysis": 0,
        "evaluation_only_retries": review,
        "aggregates": aggregates,
        "comparisons": comparisons,
        "policy_comparisons": policy,
        "size_groups": size_groups,
        "timeouts": timeouts,
        "official_without_tests_status": no_test_results,
        "uncertainty_method": {
            "unit": "task clusters, all available repetitions retained together",
            "clusters": 20,
            "resamples": 10000,
            "seed": 20261107,
            "interval": "percentile 95%, exploratory conditional on these tasks and observed valid pairs; not a noninferiority proof",
        },
        "trials": rows,
    }
    (output / "analysis.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    (output / "integrity-audit.json").write_text(
        json.dumps(
            {
                "passed": not failures,
                "checks": len(checks),
                "failures": failures,
                "raw_source_sha256": result["source_sha256"],
                "details": checks,
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n"
    )
    with (output / "paired-effects.csv").open("w") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "phase",
                "budget",
                "pairs",
                "search_delta",
                "search_ci_low",
                "search_ci_high",
                "relative_search_change",
                "localization_pairs",
                "localization_delta",
                "resolved_delta_pp",
            ]
        )
        for c in comparisons:
            s = c["search"]
            writer.writerow(
                [
                    c["phase"],
                    c["budget"],
                    s["pairs"],
                    s["delta_mean"],
                    *s["ci95"],
                    s["relative_change"],
                    c["localization"]["pairs"],
                    c["localization"]["delta_mean"],
                    c["resolved_all"]["delta_mean"],
                ]
            )
    print(
        json.dumps(
            {
                k: result[k]
                for k in (
                    "completed_attempts",
                    "valid_submissions",
                    "raw_resolved",
                    "grading_containers",
                    "billed_responses",
                    "returned_cost_usd",
                    "actual_models",
                    "evaluation_only_retries",
                )
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    print("AUDIT", len(checks), "passed", flush=True)


if __name__ == "__main__":
    main()
