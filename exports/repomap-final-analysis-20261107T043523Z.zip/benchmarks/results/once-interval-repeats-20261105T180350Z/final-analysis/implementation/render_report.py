"""Render the complete Chinese analysis, task tables and CSVs without new inference."""

import csv
import json
import os
from collections import defaultdict
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PROJECT = next(p for p in ROOT.parents if (p / "src/mini_swe_repomap").is_dir())
RUN = ROOT.parent
data = json.loads((ROOT / "analysis.json").read_text())
rows, comparisons, totals = data["trials"], data["comparisons"], data["aggregates"]
lookup = {(r["phase"], r["repeat"], r["budget"], r["instance_id"]): r for r in rows}
agg = {(a["phase"], a["budget"]): a for a in totals}


def number(value, digits=2):
    return f"{value:.{digits}f}" if value is not None else "N/A"


def interval(metric):
    return "[" + ", ".join(number(x) for x in metric["ci95"]) + "]" if metric["ci95"] else "N/A"


def pct(value):
    return f"{value:.1%}" if value is not None else "N/A"


def render(destination):
    def link(path, label):
        return f"[{label}]({os.path.relpath(path, destination.parent)})"

    lines = [
        "# Once与Interval：480次实验最终分析",
        "",
        f"分析日期：{data['created_at']}。实验于2026-11-06 10:14 UTC（柏林11:14）结束。",
        "",
        "**全部480次计划运行已结束并有评分记录：471次正常提交，9次推理硬超时；原始评分412/480解决。**",
        "其中471次创建了官方判题容器，9次超时无提交按空补丁未解决计分。全部已创建判题容器均审计为network=none。",
        "另有1条正常提交的Gson因Maven守护进程连接超时未执行目标测试；原评分保留为false，单列环境未决，不能解释为补丁语义错误。",
        "",
        "## 1. 主要结论",
        "",
        "- **Once主要节省首次定位搜索，未稳定减少全程搜索。** 相对同阶段plain，1024/2048/4096的配对全程搜索变化为+5.1%/−5.0%/+5.3%，探索性95%区间均跨0。",
        "- **Interval减少全程搜索的证据更一致。** 三档相对同阶段plain分别减少12.1%/11.0%/16.1%；任务簇重采样的探索性95%区间均低于0。4096在三轮中的搜索差值均为负。",
        "- **不能宣称成功率已证明非劣效。** interval原始通过数54/54/53对plain的53，观察上未下降；只看双方均有效的配对则为53=53、53=53、52<53。全部成功率差值的95%区间均跨0。",
        "- **动态地图的已返回费用明显更高。** interval地图组约为同预算once的3倍，输入token缓存占比约10.6%–15.0%，once约86.4%–89.9%；费用还受请求数量与输入/输出量影响，不能只归因于缓存。",
        "- **不能把跨阶段差异全部归因于刷新频率。** once用原始任务，interval用任务+最近6条消息；两个阶段顺序执行，plain本身也出现差异。做基线调整后，跨策略搜索差值的区间仍全部跨0。",
        "",
        "在这批样本中，interval4096是进一步验证“减少搜索”的候选；interval1024费用较低、观察通过数较高，是折中候选。当前没有通用最优预算或可靠的仓库长度阈值。",
        "",
        "## 2. 协议、计数与不确定性",
        "",
        "20个仓库各1条任务；once/interval两个阶段，每阶段0/1024/2048/4096四档，每档重复3次，即每条件60次。模型始终为`openrouter/deepseek/deepseek-v4.1-flash-1017`；全部10640条已计费响应的实际模型标识一致。",
        "容器断网、镜像固定、模型与运行限制一致。扫描上限为20000文件、单文件1GiB、源码总量128MiB；模型调用保持mini累计历史。once固定地图在后续历史中仍会发送；interval每轮替换一张地图。",
        "地图预算按cl100k_base编码，费用采用模型服务端实际usage，不将两种token口径混同。本轮使用mini适配版生成器，未运行Aider原版、auto或动态预算对照。",
        "",
        "- Search Calls per Task：显式Bash搜索子命令，包含grep/rg、文件定位及日志过滤，不含普通cat/sed、脚本内部搜索和地图扫描。统计请求，不保证所有条件分支执行。",
        "- 搜索调用减少只代表模型显式发出的搜索更少；本指标不计地图内部扫描，因此不能据此认定总仓库I/O、计算量、读取信息量或耗时减少。",
        "- Target Localization Cost：首次显式读取官方基线目标区域，整体工具动作退出0且模型可见输出包含参考源码。累计搜索包含定位动作；未观察到为null，不作0。它不测量模型心智、完整修复范围或地图实际利用。",
        "- Resolved Rate：主表分母包含全部60次计划运行，超时无提交计未解决；另列有效运行配对敏感性。",
        "- 全程搜索主均值只覆盖正常结束的有效推理，附有效分母；超时轨迹不当成低搜索收益。对照效果使用同任务、同重复编号的有效配对。",
        "- 95%区间：固定种子20261107，10000次按任务簇重采样，某任务的全部可用重复一起抽取。没有把60次视作60个独立任务；区间只描述这些任务与可观察运行，未作多重比较校正，不证明一般性收益或非劣效。",
        "- 原报告部分`provisional=true`是因为有效样本未满60，不表示队列仍运行。本次所有计划均已结束；不静默改写冻结报告。",
        "",
        "## 3. 三项核心指标总表",
        "",
        "| 策略 | 预算 | 有效推理/60 | 搜索/有效任务 | 定位搜索 | 定位覆盖 | 定位模型轮数 | 原官方通过/60 |",
        "| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |",
    ]
    for a in totals:
        lines.append(
            f"| {a['phase']} | {a['budget']} | {a['valid']} | {number(a['search_mean'])} | {number(a['localization_search_mean'])} | {a['localization_n']}/{a['valid']} | {number(a['localization_calls_mean'])} | {a['resolved']} ({a['resolved'] / 60:.1%}) |"
        )
    lines += [
        "",
        "上表各均值分母可能不同，不能直接相减当作严格配对效果。以下对照均在同一任务配对上计算。",
        "",
        "## 4. 相对各自Plain的配对效果",
        "",
        "| 策略 | 预算 | 配对数 | 搜索差值/任务 | 相对变化 | 探索性95%区间 | 等任务权重差值 |",
        "| --- | ---: | ---: | ---: | ---: | --- | ---: |",
    ]
    for c in comparisons:
        s = c["search"]
        lines.append(
            f"| {c['phase']} | {c['budget']} | {s['pairs']} | {s['delta_mean']:+.2f} | {s['relative_change']:+.1%} | {interval(s)} | {s['equal_task_weight_delta']:+.2f} |"
        )
    lines += [
        "",
        "差值为地图减plain，负值表示搜索更少。“等任务权重”先在任务内平均可用重复，再对20条任务等权，避免缺失重复轻微改变任务权重；方向与主配对估计一致。",
        "",
        "### 定位与定位后搜索分解",
        "",
        "| 策略 | 预算 | 双方定位可观察 | 定位搜索差值/任务 | 定位区间 | 累计定位段差值 | 累计定位后差值 |",
        "| --- | ---: | ---: | ---: | --- | ---: | ---: |",
    ]
    for c in comparisons:
        m = c["localization"]
        s = c["stage_decomposition"]
        lines.append(
            f"| {c['phase']} | {c['budget']} | {m['pairs']} | {m['delta_mean']:+.2f} | {interval(m)} | {s['through_localization_delta_sum']:+d} | {s['after_localization_delta_sum']:+d} |"
        )
    lines += [
        "",
        "阶段分解只使用双方均能观察定位的相同配对，因此分母与全程搜索表可能不同。once1024在57对中定位段少46次，定位后多80次，最后净多34次；once4096同样出现定位节省被后段抵消。",
        "once2048在55条可观察配对中定位段少32次、后段多2次；另1条定位未知配对全程少3次，合计56对净少33次。interval三档则在定位和定位后两段都观察到净节省。",
        "这些是命令阶段的描述性分解，不能直接证明某张地图造成了后续路线。",
        "",
        "## 5. 成功率约束与超时敏感性",
        "",
        "| 策略 | 预算 | 全60次成功率差（百分点） | 95%区间 | 双方有效配对成功数：plain→地图 | 配对子集成功率差 |",
        "| --- | ---: | ---: | --- | --- | ---: |",
    ]
    for c in comparisons:
        m = c["resolved_all"]
        v = c["resolved_valid_pairs"]
        a, b = c["valid_pair_success_counts"]
        lines.append(
            f"| {c['phase']} | {c['budget']} | {m['delta_mean']:+.2f} | {interval(m)} | {a}/{v['pairs']}→{b}/{v['pairs']} | {v['delta_mean']:+.2f}pp |"
        )
    lines += [
        "",
        "interval的plain第三轮Django超时；移除双方运行有效性不匹配的配对后，1024/2048的成功总数净优势消失。4096在有效配对子集上少通过1次。成功率总数相同也可能由不同任务的损失和收益抵消，须看第11节。",
        "因此“观察到成功率不下降”与“已证明非劣效”必须分开。没有预设非劣效界值，也没有充分功效论证；不能仅凭54/60对53/60宣称修复能力提高。",
        "",
        "### Gson环境未决项",
        "",
        "once第2轮4096的Gson原日志记录补丁cleanly applied，随后`mvnd`连接Maven守护进程超时，目标测试未执行；官方仍给出`infra_failure=false`且保留默认`patch_successfully_applied=false`。这里不能据默认字段认定补丁应用失败。",
        "本次在新目录仅复评同一补丁、同一镜像，未发起新推理。复评再次被相同守护进程问题阻塞，结果仍为false且无目标测试结果，不能据此判定补丁语义。原评分未覆盖。",
        "若将该条作为环境未知而从双方有效配对敏感性中同时移除，once4096变为49/56对49/56；原始50/60解决数不变。若目标测试今后通过，则该条件上界为51/60，仍没有减少全程搜索。",
        link(Path(data["evaluation_only_retries"][0]["report"]), "同补丁复评官方结果")
        + " · "
        + link(Path(data["evaluation_only_retries"][0]["report"]).parent / "test_output.txt", "复评原始测试日志")
        + "。",
        "",
        "## 6. 重复间稳定性",
        "",
        "| 策略 | 条件 | 第1轮通过/20 | 第2轮通过/20 | 第3轮通过/20 |",
        "| --- | --- | ---: | ---: | ---: |",
    ]
    for a in totals:
        lines.append(
            f"| {a['phase']} | {'plain' if not a['budget'] else a['budget']} | "
            + " | ".join(map(str, a["repeat_resolved"]))
            + " |"
        )
    lines += [
        "",
        "| 策略 | 预算 | 第1轮配对搜索差 | 第2轮 | 第3轮 | 三轮任务平均少/平/多 |",
        "| --- | ---: | ---: | ---: | ---: | ---: |",
    ]
    for c in comparisons:
        s = c["search"]
        lines.append(
            f"| {c['phase']} | {c['budget']} | "
            + " | ".join(f"{x:+.2f}" for x in c["repeat_search_delta"])
            + f" | {s['task_fewer']}/{s['task_equal']}/{s['task_more']} |"
        )
    lines += [
        "",
        "once2048的下降主要由第一轮贡献：配对净−31、+6、−8次。once1024/4096三轮配对搜索差均为正。interval4096三轮均为负，1024亦均为负；2048首轮略增，后两轮减少。初始地图在各任务、各预算的三次重复中均保持相同哈希，变化发生在后续执行轨迹，而非初始地图生成随机变化。",
        "",
        "## 7. Once与Interval的跨阶段比较",
        "",
        "| 预算 | 双方有效配对 | interval−once搜索差 | 区间 | 四条件共同配对 | 基线调整差值 | 调整后区间 |",
        "| --- | ---: | ---: | --- | ---: | ---: | --- |",
    ]
    for p in data["policy_comparisons"]:
        raw = p["raw_search"]
        adj = p["baseline_adjusted_search"]
        lines.append(
            f"| {p['budget']} | {raw['pairs']} | {number(raw['delta_mean'])} | {interval(raw)} | {adj['pairs']} | {number(adj['delta_mean'])} | {interval(adj)} |"
        )
    lines += [
        "",
        "基线调整为`(interval地图−interval plain)−(once地图−once plain)`，四个条件都有效才配对。plain跨阶段本身平均多1.64次搜索；调整有助于描述阶段差异，但不能消除服务端变化、缓存时序或任务交互。",
        "once和interval的排序上下文也不同，初始地图本身就可能不同。不能把跨阶段差异单独归因于刷新频率。全部直接及调整后的搜索区间均跨0；当前没有足够依据宣称一种策略普遍优于另一种。",
        "",
        "## 8. 地图质量与时间顺序",
        "",
        "| 策略 | 预算 | 首轮文件召回宏平均 | 最后地图 | 全程地图并集 | 每运行不同地图均值 | 首轮哈希跨重复稳定 |",
        "| --- | ---: | ---: | ---: | ---: | ---: | ---: |",
    ]
    for a in totals:
        if not a["budget"]:
            continue
        m = a["map_quality"]
        lines.append(
            f"| {a['phase']} | {a['budget']} | {pct(m['initial_recall'])} | {pct(m['final_recall'])} | {pct(m['union_recall'])} | {m['unique_maps']:.2f} | {a['initial_map_stable_tasks']}/20 |"
        )
    lines += [
        "",
        "参考为官方patch的目标文件，包含2个基线不存在的新文件；各任务等权。首轮地图每任务三次一致，独立任务数仍为20。最后及并集覆盖可能受Agent已经定位、修改甚至创建文件影响，不等于首轮质量，也不能作为早期利用证据。",
        "",
        "| 策略 | 预算 | 定位可观察样本 | 对应读取文件在定位前/同次请求已出现 | 首次出现晚于定位 | 全程未出现 |",
        "| --- | ---: | ---: | ---: | ---: | ---: |",
    ]
    for a in totals:
        if not a["budget"]:
            continue
        t = a["map_timing"]
        lines.append(
            f"| {a['phase']} | {a['budget']} | {a['localization_n']} | {t.get('before_or_same_call', 0)} | {t.get('after_localization', 0)} | {t.get('never_in_recorded_maps', 0)} |"
        )
    lines += [
        "",
        "例如interval1024有11次在已经读取目标代码之后，地图才首次列出该读取文件。不能将这11次晚出现算作初始定位的地图收益。即使地图先列出文件，也不证明Agent实际依赖了它。",
        "once2048按首轮是否列出官方目标文件分组，28对命中组净少33次搜索，28对未命中组净变化0；定位可观察子集分别少41次和多9次。分组与任务类型相关，是相关性证据，非独立随机化的命中消融。",
        "本报告计算文件召回及可见先后关系。Target Symbol Recall、Dependency Coverage、Symbol Precision和完整Map Utilization仍缺经复核标注，保持N/A，未宣称五项地图质量评测已经完成。",
        "",
        "## 9. 费用、Tokens与缓存",
        "",
        f"本轮10640条已计费响应均核对服务端usage.cost；已返回费用合计 **${data['returned_cost_usd']}**。9条超时运行存在未返回请求费用未知，不能把该数当作完整最终账单。未包含早期历史实验或先前judge调用费用；本次分析没有新模型调用。",
        "",
        "| 策略 | 预算 | 已返回USD/60次计划运行 | 相对同阶段plain | 输入token缓存占比 | API调用 | 输出tokens |",
        "| --- | ---: | ---: | ---: | ---: | ---: | ---: |",
    ]
    for a in totals:
        base = agg[(a["phase"], 0)]
        ratio = Decimal(a["returned_cost_usd"]) / Decimal(base["returned_cost_usd"])
        lines.append(
            f"| {a['phase']} | {a['budget']} | {Decimal(a['returned_cost_usd']):.6f} | {ratio:.2f}× | {a['cached_prompt_fraction']:.1%} | {a['api_calls']} | {a['completion_tokens']:,} |"
        )
    lines += [
        "",
        "缓存占比是cached prompt tokens / prompt tokens，不是API请求命中率。interval每轮改写早期地图消息，伴随前缀缓存下降；但请求数量、输出长度和提供商缓存策略也共同影响费用，不能从相关性分离出各自贡献。",
        "",
        "## 10. 超时与完整性",
        "",
        "| 策略 | 重复 | 预算 | 仓库 | 终止耗时秒 | 最后保存消息后静默秒 |",
        "| --- | ---: | ---: | --- | ---: | ---: |",
    ]
    for t in data["timeouts"]:
        phase, repeat, budget, _ = t["key"]
        lines.append(
            f"| {phase} | {repeat} | {budget} | {t['repo']} | {t['elapsed_seconds']:.1f} | {t['seconds_without_new_saved_message_before_kill']:.1f} |"
        )
    lines += [
        "",
        "9条均在1380秒进程硬时限附近被终止，最后保存消息均为工具观察，之后约1177–1367秒没有新轨迹消息。该现象与下一次查询等待/重试相容，但缺少请求级完整结束日志，不能确定提供商根因，也不能据此断言once导致超时。",
        "所有超时都发生在once或plain，不处在interval地图重建条件，因此不能用这些记录证明动态地图构建慢。原费用和部分轨迹保留，未把其少量已记录搜索作为效率收益。",
        "独立复核31468项检查通过，包括480份轨迹哈希、配置、模型、搜索计数、定位结果、逐响应费用、地图快照哈希/预算、源码冻结及471次判题容器断网。原始评分及冻结报告保持不变。",
        "",
        "## 11. 20条任务逐项结果",
        "",
        "每格是3次重复中原官方通过次数；不是仓库全量测试通过次数。两列plain属于不同阶段。",
        "",
        "| 仓库 | O-plain | O1024 | O2048 | O4096 | I-plain | I1024 | I2048 | I4096 |",
        "| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |",
    ]
    unique = sorted({(r["source_lines"], r["instance_id"], r["repo"]) for r in rows})
    for _, iid, repo in unique:
        values = [
            sum(lookup[(phase, repeat, budget, iid)]["resolved"] for repeat in (1, 2, 3))
            for phase in ("once", "interval")
            for budget in (0, 1024, 2048, 4096)
        ]
        lines.append(f"| {repo} | " + " | ".join(f"{v}/3" for v in values) + " |")
    lines += [
        "",
        "- Caddy差异尤其明显：once阶段plain为0/3，interval阶段plain为3/3；两阶段1024地图组均0/3。成功总数的净变化不能掩盖这个任务的明显退步，也说明跨阶段存在很大波动。",
        "- Fmt在interval1024为3/3，plain为1/3；与Caddy损失部分抵消。单看54/60无法看到这类任务互换。",
        "- Laravel随更大预算没有稳定改善：once4096为0/3，interval2048/4096均1/3。",
        "- SymPy大部分条件为0/3或1/3；定位正确文件和更大地图不足以保证满足距离维度语义要求。",
        "- Gson的once4096一次false属于目标测试未执行，不能归为已证实补丁错误。Tokio、Preact、Lucene的once2048各一次false为推理超时。",
        "- Lucene本次23份正常提交均通过，另1份因推理超时未提交；旧实验缺wrapper的问题已在本轮镜像预热中解决。",
        "",
        "### 每条任务相对Plain的平均搜索差",
        "",
        "| 仓库 | O1024 | O2048 | O4096 | I1024 | I2048 | I4096 |",
        "| --- | ---: | ---: | ---: | ---: | ---: | ---: |",
    ]
    for _, iid, repo in unique:
        values = []
        for c in comparisons:
            r = next(x for x in c["task_contributions"] if x["instance_id"] == iid)
            values.append(f"{r['search_delta_sum'] / r['pairs']:+.2f} ({r['pairs']}对)")
        lines.append(f"| {repo} | " + " | ".join(values) + " |")
    lines += [
        "",
        "## 12. 按仓库源码长度分组",
        "",
        "每组5个仓库、每条件15次计划运行。每格是配对搜索差值及有效配对数；不能从每仓库仅一条任务推出通用长度阈值。",
        "",
        "| 源码行数范围 | 策略 | plain通过/15 | 1024搜索差 | 2048搜索差 | 4096搜索差 |",
        "| --- | --- | ---: | ---: | ---: | ---: |",
    ]
    sizes = defaultdict(list)
    for s in data["size_groups"]:
        sizes[(s["source_lines_min"], s["source_lines_max"], s["phase"])].append(s)
    for (low, high, phase), group in sorted(sizes.items()):
        group.sort(key=lambda x: x["budget"])
        lines.append(
            f"| {low:,}–{high:,} | {phase} | {group[0]['baseline_resolved']}/15 | "
            + " | ".join(f"{s['search_delta_mean']:+.2f} ({s['pairs']}对)" for s in group)
            + " |"
        )
    lines += [
        "",
        "## 13. 与此前实验的关系",
        "",
        "最初单次once1024为17/20、plain为15/20，搜索增加10.0%。新三轮同预算once为14/17/17，plain为16/18/17；初始地图与原1024地图保持一致，但没有复现稳定成功率优势。旧Lucene当时未执行目标测试，本轮已修复，不能把新通过直接归功于地图。",
        "旧四档interval单次结果为plain16/20、1024为16、2048为16、4096为17；对应搜索234/197/242/222。本轮重复数据中三档相对同阶段plain均减少搜索，但4096不再有通过数优势。一次运行的最佳预算并非重复后的稳定赢家。",
        "此前120条轨迹补算的定位成本亦显示“定位节省与总搜索不同”：预算2048定位搜索减少27.5%，当时全程搜索却增加3.4%。本轮once1024/4096的分解进一步印证了这种区别。",
        link(PROJECT / "docs/historical-localization-cost.md", "历史定位成本")
        + " · "
        + link(PROJECT / "docs/historical-map-quality-results.md", "历史地图质量")
        + " · "
        + link(PROJECT / "docs/once-implementation-and-case-analysis.md", "原始Once逐条分析"),
        "",
        "## 14. 下一步应验证什么",
        "",
        "1. 将once与interval在相同任务/重复/预算内交错运行，同时保留两种相同排序上下文的对照，以区分刷新与最近消息的作用。",
        "2. 为查询开始、收到首块、完成、重试和取消增加独立时间记录；先确认9次硬超时原因，再预先规定基础设施补跑与费用口径，保留全部尝试。",
        "3. 单独修复Gson守护进程启动环境，再复评同一补丁；环境未决不能充当失败修复样本。",
        "4. 增加每仓库任务数量，并基于预期最小效果和当前波动设计样本量；继续用成功率约束，不能靠挑一次最优重复或按结果筛选任务来降搜索。",
        "5. 完成目标符号、关键依赖、全图符号精度及实际利用的复核标注；文件命中和时间先后都不能替代机制验证。",
        "",
        "## 15. 图表与完整材料",
        "",
        "!["
        + "配对效果及探索性95%区间"
        + "]("
        + os.path.relpath(ROOT / "figures/paired-effects.png", destination.parent)
        + ")",
        "",
        "![" + "费用与输入缓存" + "](" + os.path.relpath(ROOT / "figures/cost-cache.png", destination.parent) + ")",
        "",
        link(ROOT / "analysis.json", "完整分析JSON")
        + " · "
        + link(ROOT / "paired-effects.csv", "配对效果CSV")
        + " · "
        + link(ROOT / "task-summary.csv", "逐任务CSV")
        + " · "
        + link(ROOT / "map-temporal.csv", "地图时间指标CSV"),
        link(ROOT / "integrity-audit.json", "独立完整性复核")
        + " · "
        + link(RUN / "final-report.md", "冻结的原始汇总")
        + " · "
        + link(RUN / "final-repeat-trials.csv", "480次原始逐次CSV"),
        link(ROOT / "implementation/analyze_results.py", "分析实现")
        + " · "
        + link(ROOT / "implementation/render_report.py", "报告生成")
        + " · "
        + link(ROOT / "implementation/plot_results.py", "图表生成"),
        "",
        "本次分析未新增模型推理，未修改原始480条结果；只额外做1次Gson官方评测复核，仍为环境未决。",
        "",
    ]
    destination.write_text("\n".join(lines))


with (ROOT / "task-summary.csv").open("w") as stream:
    writer = csv.writer(stream)
    writer.writerow(
        [
            "phase",
            "budget",
            "repo",
            "instance_id",
            "planned",
            "valid",
            "resolved",
            "searches_valid",
            "localization_searches_observed",
        ]
    )
    grouped = defaultdict(list)
    for r in rows:
        grouped[(r["phase"], r["budget"], r["repo"], r["instance_id"])].append(r)
    for (phase, budget, repo, iid), sample in sorted(grouped.items()):
        writer.writerow(
            [
                phase,
                budget,
                repo,
                iid,
                len(sample),
                sum(r["run_valid"] for r in sample),
                sum(r["resolved"] for r in sample),
                json.dumps([r["search_commands"] for r in sample if r["run_valid"]]),
                json.dumps([r["localization"]["search_commands_through_action"] for r in sample]),
            ]
        )
with (ROOT / "map-temporal.csv").open("w") as stream:
    fields = [
        "phase",
        "repeat",
        "budget",
        "instance_id",
        "initial_recall",
        "final_recall",
        "union_recall",
        "unique_maps",
        "localized_path_visibility",
        "first_localized_path_visible_call",
    ]
    writer = csv.DictWriter(stream, fieldnames=fields)
    writer.writeheader()
    for r in rows:
        if r["budget"]:
            writer.writerow({**{k: r[k] for k in fields[:4]}, **{k: r["map_analysis"][k] for k in fields[4:]}})
render(ROOT / "analysis.md")
render(PROJECT / "docs/final-experiment-analysis.md")
print("Rendered full reports, task-summary.csv and map-temporal.csv")
