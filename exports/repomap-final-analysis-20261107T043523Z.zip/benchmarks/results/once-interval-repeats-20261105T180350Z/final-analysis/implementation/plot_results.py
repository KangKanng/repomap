"""Standalone scientific plots; use an isolated matplotlib runtime, not the experiment environment."""

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
data = json.loads((ROOT / "analysis.json").read_text())
out = ROOT / "figures"
out.mkdir(exist_ok=True)
colors = {"once": "#7c3aed", "interval": "#087e8b"}
plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})
comparisons = data["comparisons"]
fig, axes = plt.subplots(1, 3, figsize=(14, 5.5), sharey=True)
for ax, key, title, xlabel in zip(
    axes,
    ("search", "localization", "resolved_all"),
    ("Total search", "Target localization", "Resolved rate (all planned attempts)"),
    (
        "Search calls / task: map minus plain",
        "Search calls to target: map minus plain",
        "Percentage points: map minus plain",
    ),
    strict=True,
):
    for index, row in enumerate(comparisons):
        metric = row[key]
        point, (low, high) = metric["delta_mean"], metric["ci95"]
        ax.errorbar(point, index, xerr=[[point - low], [high - point]], fmt="o", color=colors[row["phase"]], capsize=4)
    ax.axvline(0, color="#666666", linestyle="--", linewidth=1)
    ax.grid(axis="x", alpha=0.2)
    ax.set(title=title, xlabel=xlabel)
axes[0].set_yticks(range(len(comparisons)), [f"{r['phase']} {r['budget']}" for r in comparisons])
axes[0].invert_yaxis()
fig.suptitle("Paired effects: 20 tasks, 3 repetitions per condition", fontsize=14)
fig.text(
    0.5,
    0.015,
    "Exploratory 95% task-cluster bootstrap intervals; not a noninferiority test or a population-wide claim.",
    ha="center",
    fontsize=9,
)
fig.tight_layout(rect=(0, 0.06, 1, 0.94))
for suffix in ("png", "svg"):
    fig.savefig(out / f"paired-effects.{suffix}", dpi=180, bbox_inches="tight")
plt.close(fig)

aggregates = data["aggregates"]
labels = [f"{a['phase']} {'plain' if not a['budget'] else a['budget']}" for a in aggregates]
bar_colors = [colors[a["phase"]] if a["budget"] else "#9ca3af" for a in aggregates]
fig, axes = plt.subplots(1, 2, figsize=(12, 6), sharey=True)
y = np.arange(len(aggregates))
for ax, values, title in (
    (
        axes[0],
        [float(a["returned_cost_usd"]) / a["planned"] for a in aggregates],
        "Returned server cost / planned run (USD)",
    ),
    (axes[1], [a["cached_prompt_fraction"] * 100 for a in aggregates], "Cached prompt-token fraction (%)"),
):
    ax.barh(y, values, color=bar_colors, alpha=0.85)
    ax.set(xlabel=title)
    ax.grid(axis="x", alpha=0.2)
    for index, value in enumerate(values):
        ax.text(value, index, f" {value:.4f}" if ax is axes[0] else f" {value:.1f}", va="center", fontsize=9)
axes[0].set_yticks(y, labels)
axes[0].invert_yaxis()
axes[0].set_xlim(0, max(float(a["returned_cost_usd"]) / a["planned"] for a in aggregates) * 1.25)
axes[1].set_xlim(0, 105)
fig.suptitle("Cost and input caching", fontsize=14)
fig.text(
    0.5,
    0.01,
    "Returned charges only: 9 timed-out requests have unknown unreturned charges. Values are not final provider invoices.",
    ha="center",
    fontsize=9,
)
fig.tight_layout(rect=(0, 0.05, 1, 0.95))
for suffix in ("png", "svg"):
    fig.savefig(out / f"cost-cache.{suffix}", dpi=180, bbox_inches="tight")
plt.close(fig)
(ROOT / "plotting-versions.json").write_text(
    json.dumps({"matplotlib": matplotlib.__version__, "numpy": np.__version__}, indent=2) + "\n"
)
print("Wrote 4 plot artifacts to", out)
