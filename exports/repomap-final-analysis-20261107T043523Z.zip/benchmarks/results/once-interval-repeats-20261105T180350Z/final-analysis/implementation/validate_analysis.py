"""Sanity-check statistical units, missingness, report integrity and local document links."""

import csv
import hashlib
import importlib.util
import json
import re
from collections import Counter
from pathlib import Path
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parents[1]
PROJECT = next(p for p in ROOT.parents if (p / "src/mini_swe_repomap").is_dir())
spec = importlib.util.spec_from_file_location("final_analysis_functions", ROOT / "implementation/analyze_results.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def row(task, value):
    return {"instance_id": task, "value": value}


checks = {}
pairs = [(row(str(task), 3), row(str(task), 5)) for task in range(4) for _ in range(3)]
result = module.effect(pairs, lambda r: r["value"], bootstraps=1000)
checks["constant_effect_exact_ci"] = result["delta_mean"] == 2 and result["ci95"] == [2, 2]
checks["task_clusters_not_repetitions"] = result["tasks"] == 4 and result["pairs"] == 12
missing = module.effect([*pairs, (row("unknown", None), row("unknown", 9))], lambda r: r["value"], bootstraps=1000)
checks["unknown_not_zero"] = missing["pairs"] == 12 and missing["delta_mean"] == 2
zero = module.effect([(row("zero", 0), row("zero", 1))], lambda r: r["value"], bootstraps=100)
checks["zero_baseline_relative_change_unknown"] = zero["relative_change"] is None and zero["delta_mean"] == 1
data = json.loads((ROOT / "analysis.json").read_text())
original = json.loads((ROOT.parent / "final-repeat-report.json").read_text())
checks["frozen_final_report_unchanged"] = (
    hashlib.sha256((ROOT.parent / "final-repeat-report.json").read_bytes()).hexdigest() == data["source_sha256"]
)
checks["unique_480_trials"] = (
    len({(r["phase"], r["repeat"], r["budget"], r["instance_id"]) for r in data["trials"]}) == 480
)
checks["each_condition_60"] = set(Counter((r["phase"], r["budget"]) for r in data["trials"]).values()) == {60}
checks["raw_resolved_preserved"] = sum(r["resolved"] for r in original["trials"]) == data["raw_resolved"] == 412
checks["9_timeouts_not_submission_failures"] = len(data["timeouts"]) == 9 and all(
    r["last_saved_role"] == "tool" for r in data["timeouts"]
)
checks["primary_analysis_model_calls_zero"] = data["model_calls_for_analysis"] == 0
for current in data["comparisons"]:
    previous = next(
        c for c in original["paired_comparisons"] if (c["phase"], c["budget"]) == (current["phase"], current["budget"])
    )
    key = f"{current['phase']}:{current['budget']}"
    checks["paired_point:" + key] = abs(current["search"]["delta_mean"] - previous["paired_search_delta_mean"]) < 1e-12
    checks["paired_localization:" + key] = (
        abs(current["localization"]["delta_mean"] - previous["paired_localization_search_delta_mean"]) < 1e-12
    )
for name, expected in [("task-summary.csv", 160), ("map-temporal.csv", 360), ("paired-effects.csv", 6)]:
    with (ROOT / name).open() as stream:
        checks["csv_count:" + name] = len(list(csv.DictReader(stream))) == expected
missing_links, count = [], 0
for path in [
    PROJECT / "docs/final-experiment-analysis.md",
    ROOT / "analysis.md",
    PROJECT / "docs/README.md",
    PROJECT / "docs/results.md",
    PROJECT / "docs/repeated-budget-experiment.md",
]:
    for match in re.finditer(r"\]\(([^\s)]+)\)", path.read_text()):
        target = match.group(1).split("#", 1)[0]
        if not target or "://" in target:
            continue
        count += 1
        if not (path.parent / unquote(target)).exists():
            missing_links.append({"document": str(path), "target": target})
checks["local_links_exist"] = not missing_links
checks["plots_nonempty"] = all(
    (ROOT / "figures" / f"{name}.{ext}").stat().st_size > 1000
    for name in ("paired-effects", "cost-cache")
    for ext in ("png", "svg")
)
result = {
    "passed": all(checks.values()),
    "checks": checks,
    "failures": [k for k, v in checks.items() if not v],
    "local_links_checked": count,
    "missing_links": missing_links,
}
(ROOT / "validation.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({k: v for k, v in result.items() if k != "checks"}, ensure_ascii=False, indent=2))
assert result["passed"], result["failures"]
